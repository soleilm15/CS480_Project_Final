package com.example.cs480_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddingExpenses extends AppCompatActivity implements TextToSpeech.OnInitListener{

    private EditText editAmount, editDesc;
    private Spinner chooseType;
    private Button addReceipt, saveButton, cancelButton;
    private ImageButton chooseDate;
    private TextView dateTextView, expenseIdUpdate;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private NotificationManager mManager;
    public static final String ANDROID_CHANNEL_ID = "com.chikeandroid.tutsplustalerts.ANDROID";
    public static final String ANDROID_CHANNEL_NAME = "ANDROID CHANNEL";
    public static final int SIMPLE_NOTFICATION_ID = 101;
    private TextToSpeech speaker;
    String tag = "Widgets";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_expenses);

        String title = "Expense App";
        String body = "Expense was saved successfully!";

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        // create android channel
        NotificationChannel androidChannel = new NotificationChannel(ANDROID_CHANNEL_ID,
                ANDROID_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);

        // Sets whether notifications posted to this channel should display notification lights
        androidChannel.enableLights(true);

        // Sets whether notification posted to this channel should vibrate.
        //Needs permission in Manifest
        androidChannel.enableVibration(true);
        androidChannel.setVibrationPattern(new long[] { 1000, 1000, 1000, 1000 });
        // Sets the notification light color for notifications posted to this channel
        androidChannel.setLightColor(Color.GREEN);
        // Sets whether notifications posted to this channel appear on the lockscreen or not
        androidChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

        mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        mManager.createNotificationChannel(androidChannel);

        //create Intent and PendingIntent
        Intent intent = new Intent(this, AddingExpenses.class); //explicit intent
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,PendingIntent.FLAG_IMMUTABLE);

        //create notification
        final Notification.Builder nb = new Notification.Builder(getApplicationContext(), ANDROID_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.drawable.bell)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);


        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // get references to edit text views
        editAmount = (EditText) findViewById(R.id.editAmount);
        editDesc = (EditText) findViewById(R.id.editDesc);
        dateTextView = findViewById(R.id.dateDisplay);
        expenseIdUpdate = findViewById(R.id.expenseIdUpdate);

        // references to spinners
        chooseType = (Spinner) findViewById(R.id.chooseType);

        // get references to buttons
        addReceipt = (Button) findViewById(R.id.addReceipt);
        saveButton = (Button) findViewById(R.id.save_button);
        cancelButton = (Button) findViewById(R.id.cancel_button);
        chooseDate = (ImageButton) findViewById(R.id.chooseDateButton);

        //initialize calendar and date format
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        // Create a DatePickerDialog with the current date as the default
        chooseDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddingExpenses.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String dateString = dateFormat.format(calendar.getTime());
                        chooseDate.setContentDescription(dateString);

                        dateTextView.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Set up the spinner adapter for expense types
        ArrayAdapter<CharSequence> adapterTypes = ArrayAdapter.createFromResource(
                this, R.array.expense_types, android.R.layout.simple_spinner_item);
        adapterTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseType.setAdapter(adapterTypes);

        // Get the intent that started this activity
        Intent intent1 = getIntent();

        // Check if the intent has extra data for an existing expense
        if (intent1.hasExtra("id")) {
            // If it does, retrieve the expense information from the extras
            int expenseId = intent1.getIntExtra("id", -1);
            double amount = intent1.getDoubleExtra("amount", 0);
            String category = intent1.getStringExtra("category");
            String date = intent1.getStringExtra("date");
            String description = intent1.getStringExtra("description");

            // Populate the UI elements with the expense information
            expenseIdUpdate.setText(String.valueOf(expenseId));
            editAmount.setText(String.valueOf(amount));
            chooseType.setSelection(((ArrayAdapter)chooseType.getAdapter()).getPosition(category));
            dateTextView.setText(date);
            editDesc.setText(description);
        }

        //set button to cancel activity
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //set button to save expense
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double amount = Double.parseDouble(editAmount.getText().toString());
                String category = chooseType.getSelectedItem().toString();
                String date = dateTextView.getText().toString();
                String description = editDesc.getText().toString();
                byte [] receiptImage = null;
                int budgetId = 0; // TEST

                Intent intent2 = getIntent();
                if (intent2.hasExtra("id")) {
                    int expenseId = intent2.getIntExtra("id", -1);
                    dbHelper.updateExpense(expenseId, category, amount, date, description, receiptImage);
                    mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());
                } else {
                    Expense expense = new Expense(amount, category, date, description, receiptImage, budgetId);
                    int expenseId = dbHelper.addExpense(expense);
                    expense.setId(expenseId);
                    mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());
                }

                speaker.speak("Expense saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                Toast.makeText(getApplicationContext(), "Expense Saved Successfully!", Toast.LENGTH_LONG).show();
                intent2 = new Intent(AddingExpenses.this, ViewExpenses.class);
                startActivity(intent2);
            }
        });

        //set button to allow user to upload their receipt
        addReceipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // complete later

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.addmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                finish();
                return true;
            case R.id.exit:
                Intent intent = new Intent(AddingExpenses.this, MainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }

}
