package com.example.cs480_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddingBudget extends AppCompatActivity {

    private EditText editBudget;
    private Spinner chooseBudgetType, chooseDuration, chooseOnce;
    private Button closeButton, saveButton;
    private ImageButton chooseBudgetStartDate, chooseBudgetEndDate;
    private TextView startDateTextView, endDateTextView, onceTextView, budgetIdUpdate;
    private CheckBox repeated, reminder;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_budget);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // get references to text / edit text views
        editBudget = (EditText) findViewById(R.id.total_budget);
        onceTextView = (TextView) findViewById(R.id.onceText);
        startDateTextView = (TextView) findViewById(R.id.startDateBudgetDisplay);
        endDateTextView = (TextView) findViewById(R.id.endDateBudgetDisplay);
        budgetIdUpdate = (TextView) findViewById(R.id.budgetIdUpdate);


        // get references to spinners
        chooseBudgetType = (Spinner) findViewById(R.id.category_spinner);
        chooseDuration = (Spinner) findViewById(R.id.duration_spinner);
        chooseOnce = (Spinner) findViewById(R.id.once_spinner);

        // get references to buttons
        chooseBudgetStartDate = (ImageButton) findViewById(R.id.chooseStartBudgetDateButton);
        chooseBudgetEndDate = (ImageButton) findViewById(R.id.chooseEndBudgetDateButton);
        closeButton = (Button) findViewById(R.id.close_button);
        saveButton = (Button) findViewById(R.id.saveBudgetButton);

        // get references to checkboxes
        repeated = (CheckBox) findViewById(R.id.repeated_checkbox);
        reminder = (CheckBox) findViewById(R.id.reminder_checkbox);

        //initialize calendar and date format
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        // create a DatePickerDialog with the current date as the default
        chooseBudgetStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddingBudget.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String dateString = dateFormat.format(calendar.getTime());
                        chooseBudgetStartDate.setContentDescription(dateString);

                        startDateTextView.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // create a DatePickerDialog with the current date as the default
        chooseBudgetEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddingBudget.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String dateString = dateFormat.format(calendar.getTime());
                        chooseBudgetEndDate.setContentDescription(dateString);

                        endDateTextView.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Set up the spinner adapter for budget types
        ArrayAdapter<CharSequence> adapterBudgetTypes = ArrayAdapter.createFromResource(
                this, R.array.budget_types, android.R.layout.simple_spinner_item);
        adapterBudgetTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseBudgetType.setAdapter(adapterBudgetTypes);

        // Set up the spinner adapter for budget duration
        ArrayAdapter<CharSequence> adapterDuration = ArrayAdapter.createFromResource(
                this, R.array.budget_duration, android.R.layout.simple_spinner_item);
        adapterDuration.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseDuration.setAdapter(adapterDuration);

        // Set up the spinner adapter for the "once" dropdown
        ArrayAdapter<CharSequence> adapterOnce = ArrayAdapter.createFromResource(
                this, R.array.once_dropdown, android.R.layout.simple_spinner_item);
        adapterOnce.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseOnce.setAdapter(adapterOnce);

        // Get the intent that started this activity
        Intent intent = getIntent();

        // Check if the intent has extra data for an existing expense
        if (intent.hasExtra("id")) {
            // If it does, retrieve the expense information from the extras
            int budgetId = intent.getIntExtra("id", -1);
            double amount = intent.getDoubleExtra("amount", 0);
            String category = intent.getStringExtra("category");
            String startdate = intent.getStringExtra("startDate");
            String enddate = intent.getStringExtra("endDate");

            // Populate the UI elements with the expense information
            budgetIdUpdate.setText(String.valueOf(budgetId));
            editBudget.setText(String.valueOf(amount));
            chooseBudgetType.setSelection(((ArrayAdapter) chooseBudgetType.getAdapter()).getPosition(category));
            startDateTextView.setText(startdate);
            endDateTextView.setText(enddate);
        }

        //set button to close activity
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //set button to save and close activity
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double amountBudget = Double.parseDouble(editBudget.getText().toString());
                int id = 1;
                String category = chooseBudgetType.getSelectedItem().toString();
                String startDate = startDateTextView.getText().toString();
                String endDate = endDateTextView.getText().toString();

                Budget budget = new Budget(id, amountBudget, category, startDate, endDate);
                dbHelper.addBudget(budget);

                Toast.makeText(AddingBudget.this, "Budget Saved Successfully", Toast.LENGTH_SHORT).show();
                finish();

            }
        });

        //sets visibility to gone so that these don't appear when the reminder is not checked
        chooseOnce.setVisibility(View.GONE);
        onceTextView.setVisibility(View.GONE);

        //sets the checkbox so that the choose once dropdown appears if its checked
        reminder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                chooseOnce.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                onceTextView.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(AddingBudget.this, MainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
