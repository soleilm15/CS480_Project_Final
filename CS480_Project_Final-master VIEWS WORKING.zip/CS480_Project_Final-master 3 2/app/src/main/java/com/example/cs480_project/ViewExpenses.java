package com.example.cs480_project;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ViewExpenses extends AppCompatActivity implements TextToSpeech.OnInitListener{
    private TableLayout expenseTableLayout;
    private List<Expense> expensesList;
    ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(this);
    int expensePosition = -1;
    private TextToSpeech speaker;
    String tag = "Widgets";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_expenses);

        expenseTableLayout = findViewById(R.id.expenseTableLayout);
        expensesList = new ArrayList<>();

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        expensesList = dbHelper.selectExpenses();

        for (Expense expense: expensesList) {
            TableRow row = new TableRow(this);
            row.setTag(expense.getId());

            TextView idTextView = new TextView(this);
            idTextView.setText(String.valueOf(expense.getId()));
            idTextView.setPadding(8,8,8,8);
            row.addView(idTextView);

            TextView amountTextView = new TextView(this);
            amountTextView.setText(String.valueOf(expense.getAmount()));
            amountTextView.setPadding(8,8,8,8);
            row.addView(amountTextView);

            TextView categoryTextView = new TextView(this);
            categoryTextView.setText(expense.getCategory());
            categoryTextView.setPadding(8,8,8,8);
            row.addView(categoryTextView);

            TextView dateTextView = new TextView(this);
            dateTextView.setText(expense.getDate());
            dateTextView.setPadding(8,8,8,8);
            row.addView(dateTextView);

            TextView descTextView = new TextView(this);
            descTextView.setText(expense.getDescription());
            descTextView.setPadding(8,8,8,8);
            row.addView(descTextView);

            expenseTableLayout.addView(row);
        }

        for (int i = 0; i < expenseTableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) expenseTableLayout.getChildAt(i);
            int finalI = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    expensePosition = finalI;
                }
            });

            // item click listener for the row
            row.setTag(i);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    expensePosition = (int) v.getTag();
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(ViewExpenses.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.add:
                intent = new Intent(ViewExpenses.this, AddingExpenses.class);
                startActivity(intent);
                return true;
            case R.id.delete:
                // get the tag (id) of the row to delete
                View row = expenseTableLayout.getChildAt(expensePosition);
                int id = (int) row.getTag();
                // delete the expense from the database
                dbHelper.deleteExpense(id);
                // remove the row from the table
                expenseTableLayout.removeViewAt(expensePosition);

                speaker.speak("Expense deleted successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                Toast.makeText(this, "Expense Deleted Successfully!", Toast.LENGTH_LONG).show();
                return true;
            case R.id.edit:
                row = expenseTableLayout.getChildAt(expensePosition);
                id = (int) row.getTag();

                for (Expense expense : expensesList) {
                    if (expense.getId() == id) {
                        Expense selectedExpense = expense;
                        intent = new Intent(ViewExpenses.this, AddingExpenses.class);

                        intent.putExtra("id", selectedExpense.getId());
                        intent.putExtra("amount", selectedExpense.getAmount());
                        intent.putExtra("category", selectedExpense.getCategory());
                        intent.putExtra("date", selectedExpense.getDate());
                        intent.putExtra("description", selectedExpense.getDescription());
                        intent.putExtra("receiptImage", selectedExpense.getReceiptImage());
                        intent.putExtra("budgetId", selectedExpense.getBudgetId());

                        startActivity(intent);
                    } else {continue;}
                }
                return true;
            case R.id.save:
                saveList();
                return true;
            case R.id.exit:
                saveList();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveList() {
        try {
            File file = new File(getFilesDir(), "list.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);

            for (Expense expense : expensesList) {
                osw.write(expense + "\n");
            }
            osw.close();
            fos.close();

            speaker.speak("List saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
            Toast.makeText(this, "List saved successfully!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: List saved unsuccessfully.", Toast.LENGTH_LONG).show();
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }
}
