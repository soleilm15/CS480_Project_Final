package com.example.cs480_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;

import java.text.DecimalFormat;
import java.util.AbstractCollection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView totalExpenses, totalBudget, expenseTitle, budgetTitle;
    private Spinner totalTypes;
    private Button viewExpenses, viewBudgets;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);


        ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();


        //create cursor with sql statement selecting the amount from each expense
        Cursor cursor = db.rawQuery("SELECT SUM(amount) FROM expense", null);

        double expensesum = 0;
        if (cursor.moveToFirst()) {
            expensesum = cursor.getInt(0);
        }

        //initialize title textviews
        expenseTitle = findViewById(R.id.title1);
        budgetTitle = findViewById(R.id.title2);

        //initialize buttons
        viewExpenses = findViewById(R.id.viewExpenseButton);
        viewBudgets = findViewById(R.id.viewBudgetsButton);

        viewExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ViewExpenses.class);
                startActivity(intent);
            }
        });

        viewBudgets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ViewBudgets.class);
                startActivity(intent);
            }
        });

        //format totals to two decimal places
        DecimalFormat decimalFormat = new DecimalFormat("#.00");

        //initialize and display the total sum of expenses
        totalExpenses = findViewById(R.id.totalExpensesView);
        totalExpenses.setText("$ " + decimalFormat.format(expensesum));

        //create cursor with sql statement selecting the total amount from each budget
        Cursor cursor1 = db.rawQuery("SELECT SUM(amount) FROM budget", null);
        double budgetsum = 0;
        if (cursor1.moveToFirst()){
            budgetsum = cursor1.getInt(0);
        }

        //initialize and display the total sum of budgets
        totalBudget = findViewById(R.id.totalBudgetView);
        totalBudget.setText("$ " + decimalFormat.format(budgetsum));

        //initialize spinner
        totalTypes = findViewById(R.id.totalSpinner);

        // Set up the spinner adapter for budget types
        ArrayAdapter<CharSequence> adapterTotalTypes = ArrayAdapter.createFromResource(
                this, R.array.total_types, android.R.layout.simple_spinner_item);
        adapterTotalTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        totalTypes.setAdapter(adapterTotalTypes);

        // Attach an OnItemSelectedListener to the spinner
        totalTypes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Retrieve the selected item from the spinner
                String selectedCategory = parent.getItemAtPosition(position).toString();

                // Construct the SQL query to retrieve the totals for the selected category
                String query = "";
                String query2 = "";
                switch (selectedCategory) {
                    case "All Expense/Budget Types":
                        query = "SELECT SUM(amount) FROM expense";
                        query2 = "SELECT SUM(amount) FROM budget";

                        // Execute the SQL query and retrieve the totals
                        Cursor cursor1 = db.rawQuery(query, null);
                        double total = 0;
                        if (cursor1.moveToFirst()) {
                            total = cursor1.getDouble(0);
                        }

                        // Execute the SQL query and retrieve the totals
                        Cursor cursor2 = db.rawQuery(query2, null);
                        double total2 = 0;
                        if (cursor2.moveToFirst()) {
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("All Expense/Budget Types")) {
                            expenseTitle.setText("Total Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Automotive":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Automotive'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Automotive'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Automotive")) {
                            expenseTitle.setText("Total 'Automotive' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Automotive' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }

                        break;
                    case "Bills / Utilities":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Bills / Utilities'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Bills / Utilities'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Bills / Utilities")) {
                            expenseTitle.setText("Total 'Bills / Utilities' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Bills / Utilities' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Entertainment":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Entertainment'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Entertainment'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Entertainment")) {
                            expenseTitle.setText("Total 'Entertainment' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Entertainment' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Food / Drink":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Food / Drink'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Food / Drink'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Food / Drink")) {
                            expenseTitle.setText("Total 'Food / Drink' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Food / Drink' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Gas":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Gas'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Gas'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Gas")) {
                            expenseTitle.setText("Total 'Gas' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Gas' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Groceries":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Groceries'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Groceries'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Groceries")) {
                            expenseTitle.setText("Total 'Groceries' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Groceries' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Health / Wellness":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Health / Wellness'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Health / Wellness'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Health / Wellness")) {
                            expenseTitle.setText("Total 'Health / Wellness' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Health / Wellness' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Personal":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Personal'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Personal'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Personal")) {
                            expenseTitle.setText("Total 'Personal' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Personal' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Shopping":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Shopping'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Shopping'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Shopping")) {
                            expenseTitle.setText("Total 'Shopping' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Shopping' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;

                    case "Travel":
                        query = "SELECT SUM(amount) FROM expense WHERE category = 'Travel'";
                        query2 = "SELECT SUM(amount) FROM budget WHERE category = 'Travel'";

                        // Execute the SQL query and retrieve the totals
                        cursor1 = db.rawQuery(query, null);
                        cursor2 = db.rawQuery(query2, null);
                        total = 0;
                        total2 = 0;
                        if (cursor1.moveToFirst() && cursor2.moveToFirst()) {
                            total = cursor1.getDouble(0);
                            total2 = cursor2.getDouble(0);
                        }

                        // Set the retrieved totals in the TextView
                        if (selectedCategory.equals("Travel")) {
                            expenseTitle.setText("Total 'Travel' Expenses:");
                            totalExpenses.setText("$ " + decimalFormat.format(total));
                            budgetTitle.setText("Total 'Travel' Budget:");
                            totalBudget.setText("$ " + decimalFormat.format(total2));
                        }
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addExpense:
                Intent intent = new Intent(MainActivity.this, AddingExpenses.class);
                startActivity(intent);
                return true;
            case R.id.addBudget:
                intent = new Intent(MainActivity.this, AddingBudget.class);
                startActivity(intent);
                return true;
            case R.id.viewExpenses:
                intent = new Intent(MainActivity.this, ViewExpenses.class);
                startActivity(intent);
                return true;
            case R.id.viewBudgets:
                intent = new Intent(MainActivity.this, ViewBudgets.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
