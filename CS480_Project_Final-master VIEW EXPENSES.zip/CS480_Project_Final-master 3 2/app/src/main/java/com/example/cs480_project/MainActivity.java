package com.example.cs480_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;

import java.text.DecimalFormat;
import java.util.AbstractCollection;
import java.util.ArrayList;

// NOTE: NOTIFICATIONS ONLY APPEAR ON API 32 OR BELOW

public class MainActivity extends AppCompatActivity {

    private TextView totalExpenses;
    private TextView totalBudget;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);


        ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();


        //create cursor with sql statement selecting the amount from each expense
        Cursor cursor = db.rawQuery("SELECT SUM(amount) FROM expense", null);

        double expensesum = 0;
        if (cursor.moveToFirst()) {
            expensesum = cursor.getInt(0);
        }

        //format totals to two decimal places
        DecimalFormat decimalFormat = new DecimalFormat("#.00");

        //initialize and display the total sum of expenses
        totalExpenses = findViewById(R.id.totalExpensesView);
        totalExpenses.setText("$ " + decimalFormat.format(expensesum));

        //create cursor with sql statement selecting the total amount from each budget
        Cursor cursor1 = db.rawQuery("SELECT SUM(amount) FROM budget", null);
        double budgetsum = 0;
        if (cursor1.moveToFirst()){
            budgetsum = cursor1.getInt(0);
        }

        //initialize and display the total sum of budgets
        totalBudget = findViewById(R.id.totalBudgetView);
        totalBudget.setText("$ " + decimalFormat.format(budgetsum));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addExpense:
                Intent intent = new Intent(MainActivity.this, AddingExpenses.class);
                startActivity(intent);
                return true;
            case R.id.addBudget:
                intent = new Intent(MainActivity.this, AddingBudget.class);
                startActivity(intent);
                return true;
            case R.id.viewExpenses:
                intent = new Intent(MainActivity.this, ViewExpenses.class);
                startActivity(intent);
                return true;
            case R.id.viewBudgets:
                intent = new Intent(MainActivity.this, ViewBudgets.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
