package com.example.cs480_project;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ViewBudgets extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private TableLayout budgetTableLayout;
    private List<Budget> budgetList;
    int budgetPos = -1;
    ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(this);
    private TextToSpeech speaker;
    String tag = "Widgets";
    private NotificationManager mManager;
    public static final String ANDROID_CHANNEL_ID = "com.chikeandroid.tutsplustalerts.ANDROID";
    public static final String ANDROID_CHANNEL_NAME = "ANDROID CHANNEL";
    public static final int SIMPLE_NOTFICATION_ID = 101;
    String title = "Expense App";
    String body = "Budget deleted successfully!";


    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_budgets);

        budgetTableLayout = findViewById(R.id.budgetTableLayout);
        budgetList = new ArrayList<>();

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        budgetList = dbHelper.selectBudgets();

        ArrayAdapter<Budget> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, budgetList);

        for (Budget budget: budgetList) {
            TableRow row = new TableRow(this);

            TextView idTextView = new TextView(this);
            idTextView.setText(String.valueOf(budget.getId()));
            idTextView.setPadding(8,8,8,8);
            row.addView(idTextView);

            TextView amountTextView = new TextView(this);
            amountTextView.setText(String.valueOf(budget.getAmount()));
            amountTextView.setPadding(8,8,8,8);
            row.addView(amountTextView);

            TextView categoryTextView = new TextView(this);
            categoryTextView.setText(budget.getCategory());
            categoryTextView.setPadding(8,8,8,8);
            row.addView(categoryTextView);

            TextView startDateTextView = new TextView(this);
            startDateTextView.setText(budget.getStartDate());
            startDateTextView.setPadding(8,8,8,8);
            row.addView(startDateTextView);

            TextView endDateTextView = new TextView(this);
            endDateTextView.setText(budget.getEndDate());
            endDateTextView.setPadding(8,8,8,8);
            row.addView(endDateTextView);

            budgetTableLayout.addView(row);
        }

        for (int i = 0; i < budgetTableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) budgetTableLayout.getChildAt(i);
            int finalI = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    budgetPos = finalI;
                }
            });

            // item click listener for the row
            row.setTag(i);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    budgetPos = (int) v.getTag();
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(ViewBudgets.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.add:
                intent = new Intent(ViewBudgets.this, AddingBudget.class);
                startActivity(intent);
                return true;
            case R.id.delete:
                // create android channel
                mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel androidChannel = new NotificationChannel(ANDROID_CHANNEL_ID,
                        ANDROID_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);

                // Sets whether notifications posted to this channel should display notification lights
                androidChannel.enableLights(true);

                // Sets whether notification posted to this channel should vibrate.
                androidChannel.enableVibration(true);
                androidChannel.setVibrationPattern(new long[] { 1000, 1000, 1000, 1000 });
                // Sets the notification light color for notifications posted to this channel
                androidChannel.setLightColor(Color.GREEN);
                // Sets whether notifications posted to this channel appear on the lockscreen or not
                androidChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

                mManager.createNotificationChannel(androidChannel);

                //create Intent and PendingIntent
                Intent notificationIntent = new Intent(this, AddingExpenses.class); //explicit intent
                PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,PendingIntent.FLAG_IMMUTABLE);

                //create notification
                final Notification.Builder nb = new Notification.Builder(getApplicationContext(), ANDROID_CHANNEL_ID)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setSmallIcon(R.drawable.bell)
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);
                mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());

                // Get the tag (id) of the row to delete
                View row = budgetTableLayout.getChildAt(budgetPos);
                TextView firstColumn = (TextView) ((TableRow) row).getChildAt(0);
                String text = firstColumn.getText().toString();
                int id = Integer.parseInt(text);

                // remove expense from database
                dbHelper.deleteBudget(id);

                // remove the row from the table
                budgetTableLayout.removeViewAt(budgetPos);

                speaker.speak("Budget deleted successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                Toast.makeText(this, "Budget Deleted Successfully!", Toast.LENGTH_LONG).show();
                return true;

            case R.id.edit:
                row = budgetTableLayout.getChildAt(budgetPos);
                firstColumn = (TextView) ((TableRow) row).getChildAt(0);
                text = firstColumn.getText().toString();
                id = Integer.parseInt(text);

                for (Budget budget : budgetList) {
                    if (budget.getId() == id) {
                        Budget selectedBudget = budget;
                        intent = new Intent(ViewBudgets.this, AddingBudget.class);

                        intent.putExtra("id", selectedBudget.getId());
                        intent.putExtra("amount", selectedBudget.getAmount());
                        intent.putExtra("category", selectedBudget.getCategory());
                        intent.putExtra("startDate", selectedBudget.getStartDate());
                        intent.putExtra("endDate", selectedBudget.getEndDate());
                        intent.putExtra("reminder", selectedBudget.getReminder());

                        startActivity(intent);
                    } else {continue;}
                }
                return true;

            case R.id.sendText:
                Intent smsIntent = new Intent(Intent.ACTION_SEND);
                smsIntent.setType("text/plain");

                // Get the file path of the list.txt file
                File file = new File(getFilesDir(), "list.txt");
                Uri fileUri = FileProvider.getUriForFile(this, "com.example.cs480_project.files", file);

                smsIntent.putExtra(Intent.EXTRA_STREAM, fileUri); // Attach the file to the intent
                smsIntent.putExtra("sms_body", "Here is the report for the budgets."); // Add message body

                // Open the SMS app chooser
                Intent chooserIntent = Intent.createChooser(smsIntent, "Send SMS");
                chooserIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(chooserIntent);
                return true;

            case R.id.sendEmail:
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"soleilmaldonado15@gmail.com"});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Expense List");
                emailIntent.putExtra(Intent.EXTRA_TEXT, readListFromFile());
                if (emailIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(Intent.createChooser(emailIntent, "Send email..."));
                } else {
                    Toast.makeText(this, "No email app found!", Toast.LENGTH_SHORT).show();
                }
                return true;

            case R.id.save:
                saveList();
                return true;
            case R.id.exit:
                saveList();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveList() {
        try {
            File file = new File(getFilesDir(), "list.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);

            for (Budget budget: budgetList) {
                osw.write(budget + "\n");
            }
            osw.close();
            fos.close();

            speaker.speak("List saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
            Toast.makeText(this, "List saved successfully!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: List saved unsuccessfully.", Toast.LENGTH_LONG).show();
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }

    private String readListFromFile() {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            FileInputStream fileInputStream = openFileInput("list.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line).append("\n");
            }
            bufferedReader.close();
            inputStreamReader.close();
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

}