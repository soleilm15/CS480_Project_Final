package com.example.cs480_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddingBudget extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private EditText editBudget;
    private Spinner chooseBudgetType, chooseOnce;
    private Button closeButton, saveButton;
    private ImageButton chooseBudgetStartDate, chooseBudgetEndDate;
    private TextView startDateTextView, endDateTextView, onceTextView, budgetIdUpdate;
    private CheckBox reminder;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private NotificationManager mManager;
    public static final String ANDROID_CHANNEL_ID = "com.chikeandroid.tutsplustalerts.ANDROID";
    public static final String ANDROID_CHANNEL_NAME = "ANDROID CHANNEL";
    public static final int SIMPLE_NOTFICATION_ID = 101;
    private TextToSpeech speaker;
    String tag = "Widgets";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_budget);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        String title = "Expense App";
        String body = "Budget was saved successfully!";

        // create android channel
        NotificationChannel androidChannel = new NotificationChannel(ANDROID_CHANNEL_ID,
                ANDROID_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);

        // Sets whether notifications posted to this channel should display notification lights
        androidChannel.enableLights(true);

        // Sets whether notification posted to this channel should vibrate.
        //Needs permission in Manifest
        androidChannel.enableVibration(true);
        androidChannel.setVibrationPattern(new long[] { 1000, 1000, 1000, 1000 });
        // Sets the notification light color for notifications posted to this channel
        androidChannel.setLightColor(Color.GREEN);
        // Sets whether notifications posted to this channel appear on the lockscreen or not
        androidChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

        mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        mManager.createNotificationChannel(androidChannel);

        //create Intent and PendingIntent
        Intent intent = new Intent(this, AddingExpenses.class); //explicit intent
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,PendingIntent.FLAG_IMMUTABLE);

        //create notification
        final Notification.Builder nb = new Notification.Builder(getApplicationContext(), ANDROID_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.drawable.bell)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // get references to text / edit text views
        editBudget = (EditText) findViewById(R.id.total_budget);
        onceTextView = (TextView) findViewById(R.id.onceText);
        startDateTextView = (TextView) findViewById(R.id.startDateBudgetDisplay);
        endDateTextView = (TextView) findViewById(R.id.endDateBudgetDisplay);
        budgetIdUpdate = (TextView) findViewById(R.id.budgetIdUpdate);


        // get references to spinners
        chooseBudgetType = (Spinner) findViewById(R.id.category_spinner);
        chooseOnce = (Spinner) findViewById(R.id.once_spinner);

        // get references to buttons
        chooseBudgetStartDate = (ImageButton) findViewById(R.id.chooseStartBudgetDateButton);
        chooseBudgetEndDate = (ImageButton) findViewById(R.id.chooseEndBudgetDateButton);
        closeButton = (Button) findViewById(R.id.close_button);
        saveButton = (Button) findViewById(R.id.saveBudgetButton);

        // get references to checkboxes
        reminder = (CheckBox) findViewById(R.id.reminder_checkbox);

        //initialize calendar and date format
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        // create a DatePickerDialog with the current date as the default
        chooseBudgetStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddingBudget.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String dateString = dateFormat.format(calendar.getTime());
                        chooseBudgetStartDate.setContentDescription(dateString);

                        startDateTextView.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // create a DatePickerDialog with the current date as the default
        chooseBudgetEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddingBudget.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        String dateString = dateFormat.format(calendar.getTime());
                        chooseBudgetEndDate.setContentDescription(dateString);

                        endDateTextView.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Set up the spinner adapter for budget types
        ArrayAdapter<CharSequence> adapterBudgetTypes = ArrayAdapter.createFromResource(
                this, R.array.budget_types, android.R.layout.simple_spinner_item);
        adapterBudgetTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseBudgetType.setAdapter(adapterBudgetTypes);

        // Set up the spinner adapter for the "once" dropdown
        ArrayAdapter<CharSequence> adapterOnce = ArrayAdapter.createFromResource(
                this, R.array.once_dropdown, android.R.layout.simple_spinner_item);
        adapterOnce.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseOnce.setAdapter(adapterOnce);

        // Get the intent that started this activity
        Intent intent1 = getIntent();

        // Check if the intent has extra data for an existing budget
        if (intent1.hasExtra("id")) {
            // If it does, retrieve the expense information from the extras
            int budgetId = intent1.getIntExtra("id", -1);
            double amount = intent1.getDoubleExtra("amount", 0);
            String category = intent1.getStringExtra("category");
            String startDate = intent1.getStringExtra("startDate");
            String endDate = intent1.getStringExtra("endDate");
            int reminder = intent1.getIntExtra("reminder", -1);
            String frequency = intent1.getStringExtra("frequency");

            // Populate the UI elements with the budget information
            budgetIdUpdate.setText(String.valueOf(budgetId));
            editBudget.setText(String.valueOf(amount));
            chooseBudgetType.setSelection(((ArrayAdapter) chooseBudgetType.getAdapter()).getPosition(category));
            startDateTextView.setText(startDate);
            endDateTextView.setText(endDate);
            chooseOnce.setSelection(((ArrayAdapter) chooseOnce.getAdapter()).getPosition(frequency));
        }

        //set button to close activity
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //set button to save and close activity
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double amountBudget = Double.parseDouble(editBudget.getText().toString());
                String category = chooseBudgetType.getSelectedItem().toString();
                String startDate = startDateTextView.getText().toString();
                String endDate = endDateTextView.getText().toString();
                // if checkbox is selected, reminder = 1
                int reminder = 1;

                Intent intent1 = getIntent();
                if (intent1.hasExtra("id")) {
                    int budgetId = intent1.getIntExtra("id", -1);
                    dbHelper.updateBudget(budgetId, amountBudget, category, startDate, endDate, reminder);
                    mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());
                } else {
                    Budget budget = new Budget(amountBudget, category, startDate, endDate, reminder);
                    int budgetId = dbHelper.addBudget(budget);
                    budget.setId(budgetId);
                    mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());
                }

                speaker.speak("Budget saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                Toast.makeText(getApplicationContext(), "Budget Saved Successfully!", Toast.LENGTH_LONG).show();
                intent1 = new Intent(AddingBudget.this, ViewBudgets.class);
                startActivity(intent1);
            }
        });

        //sets visibility to gone so that these don't appear when the reminder is not checked
        chooseOnce.setVisibility(View.GONE);
        onceTextView.setVisibility(View.GONE);

        //sets the checkbox so that the choose once dropdown appears if its checked
        reminder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                chooseOnce.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                onceTextView.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(AddingBudget.this, MainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }
}
