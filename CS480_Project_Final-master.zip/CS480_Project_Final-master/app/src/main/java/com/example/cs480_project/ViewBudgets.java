package com.example.cs480_project;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class ViewBudgets extends AppCompatActivity {
    private ListView budgetListView = findViewById(R.id.budgetListView);
    private List<Budget> budgetList;
    ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(this);


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_budgets);

        budgetList = new ArrayList<>();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        budgetList = dbHelper.selectBudgets();

        ArrayAdapter<Budget> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, budgetList);
        budgetListView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(ViewBudgets.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.add:
                intent = new Intent(ViewBudgets.this, AddingBudget.class);
                startActivity(intent);
                return true;
            case R.id.delete:
                Budget selectedBudget = (Budget) budgetListView.getSelectedItem();
                dbHelper.deleteBudget(selectedBudget.getId());
                budgetList.remove(selectedBudget);

                ArrayAdapter<Budget> adapter = (ArrayAdapter<Budget>) budgetListView.getAdapter();
                adapter.notifyDataSetChanged();

                Toast.makeText(this, "Budget Deleted Successfully!", Toast.LENGTH_LONG).show();
                return true;
            case R.id.edit:
                selectedBudget = (Budget) budgetListView.getSelectedItem();
                intent = new Intent(ViewBudgets.this, AddingBudget.class);
                intent.putExtra("id", selectedBudget.getId());
                intent.putExtra("amount", selectedBudget.getAmount());
                intent.putExtra("category", selectedBudget.getCategory());
                intent.putExtra("startDate", selectedBudget.getStartDate());
                intent.putExtra("endDate", selectedBudget.getEndDate());

                startActivity(intent);
                return true;
            case R.id.save:
                // saveList();
                return true;
            case R.id.exit:
                // saveList();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /*
    private void saveList() {
        try {
            File file = new File(getFilesDir(), "list.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);

            for (String item : items) {
                osw.write(item + "\n");
            }
            osw.close();
            fos.close();

            Toast.makeText(this, "List saved successfully!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: List saved unsuccessfully.", Toast.LENGTH_LONG).show();
        }
    }
     */
}