package com.example.cs480_project;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ViewExpenses extends AppCompatActivity implements TextToSpeech.OnInitListener{
    private TableLayout expenseTableLayout;
    private List<Expense> expensesList;
    ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(this);
    int expensePosition = -1;
    private TextToSpeech speaker;
    String tag = "Widgets";
    private NotificationManager mManager;
    public static final String ANDROID_CHANNEL_ID = "com.chikeandroid.tutsplustalerts.ANDROID";
    public static final String ANDROID_CHANNEL_NAME = "ANDROID CHANNEL";
    public static final int SIMPLE_NOTFICATION_ID = 101;
    String title = "Expense App";
    String body = "Expense deleted successfully!";

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_expenses);

        expenseTableLayout = findViewById(R.id.expenseTableLayout);
        expensesList = new ArrayList<>();

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        expensesList = dbHelper.selectExpenses();

        for (Expense expense: expensesList) {
            TableRow row = new TableRow(this);
            row.setTag(expense.getId());

            TextView idTextView = new TextView(this);
            idTextView.setText(String.valueOf(expense.getId()));
            idTextView.setPadding(8,8,8,8);
            row.addView(idTextView);

            TextView amountTextView = new TextView(this);
            amountTextView.setText(String.valueOf(expense.getAmount()));
            amountTextView.setPadding(8,8,8,8);
            row.addView(amountTextView);

            TextView categoryTextView = new TextView(this);
            categoryTextView.setText(expense.getCategory());
            categoryTextView.setPadding(8,8,8,8);
            row.addView(categoryTextView);

            TextView dateTextView = new TextView(this);
            dateTextView.setText(expense.getDate());
            dateTextView.setPadding(8,8,8,8);
            row.addView(dateTextView);

            TextView descTextView = new TextView(this);
            descTextView.setText(expense.getDescription());
            descTextView.setPadding(8,8,8,8);
            row.addView(descTextView);

            expenseTableLayout.addView(row);
        }

        for (int i = 0; i < expenseTableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) expenseTableLayout.getChildAt(i);
            int finalI = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    expensePosition = finalI;
                }
            });

            // item click listener for the row
            row.setTag(i);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    expensePosition = (int) v.getTag();
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(ViewExpenses.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.add:
                intent = new Intent(ViewExpenses.this, AddingExpenses.class);
                startActivity(intent);
                return true;
            case R.id.delete:

                // create android channel
                mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel androidChannel = new NotificationChannel(ANDROID_CHANNEL_ID,
                        ANDROID_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);

                // Sets whether notifications posted to this channel should display notification lights
                androidChannel.enableLights(true);

                // Sets whether notification posted to this channel should vibrate.
                androidChannel.enableVibration(true);
                androidChannel.setVibrationPattern(new long[] { 1000, 1000, 1000, 1000 });
                // Sets the notification light color for notifications posted to this channel
                androidChannel.setLightColor(Color.GREEN);
                // Sets whether notifications posted to this channel appear on the lockscreen or not
                androidChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

                mManager.createNotificationChannel(androidChannel);

                //create Intent and PendingIntent
                Intent notificationIntent = new Intent(this, AddingExpenses.class); //explicit intent
                PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,PendingIntent.FLAG_IMMUTABLE);

                //create notification
                final Notification.Builder nb = new Notification.Builder(getApplicationContext(), ANDROID_CHANNEL_ID)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setSmallIcon(R.drawable.bell)
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

                // Get the tag (id) of the row to delete
                View row = expenseTableLayout.getChildAt(expensePosition);
                TextView firstColumn = (TextView) ((TableRow) row).getChildAt(0);
                String text = firstColumn.getText().toString();
                int id = Integer.parseInt(text);

                // remove expense from database
                dbHelper.deleteExpense(id);

                // remove the row from the table
                expenseTableLayout.removeViewAt(expensePosition);

                speaker.speak("Expense deleted successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                mManager.notify(SIMPLE_NOTFICATION_ID, nb.build());
                Toast.makeText(this, "Expense Deleted Successfully!", Toast.LENGTH_LONG).show();
                return true;
            case R.id.edit:
                row = expenseTableLayout.getChildAt(expensePosition);
                firstColumn = (TextView) ((TableRow) row).getChildAt(0);
                text = firstColumn.getText().toString();
                id = Integer.parseInt(text);

                for (Expense expense : expensesList) {
                    if (expense.getId() == id) {
                        Expense selectedExpense = expense;
                        intent = new Intent(ViewExpenses.this, AddingExpenses.class);

                        intent.putExtra("id", selectedExpense.getId());
                        intent.putExtra("amount", selectedExpense.getAmount());
                        intent.putExtra("category", selectedExpense.getCategory());
                        intent.putExtra("date", selectedExpense.getDate());
                        intent.putExtra("description", selectedExpense.getDescription());
                        intent.putExtra("receiptImage", selectedExpense.getReceiptImage());
                        intent.putExtra("budgetId", selectedExpense.getBudgetId());

                        startActivity(intent);
                    } else {continue;}
                }
                return true;
            case R.id.save:
                saveList();
                return true;

            case R.id.sendText:
                Intent smsIntent = new Intent(Intent.ACTION_SEND);
                smsIntent.setType("text/plain");

                // Get the file path of the list.txt file
                File file = new File(getFilesDir(), "list.txt");
                Uri fileUri = FileProvider.getUriForFile(this, "com.example.cs480_project.files", file);

                smsIntent.putExtra(Intent.EXTRA_STREAM, fileUri); // Attach the file to the intent
                smsIntent.putExtra("sms_body", "Here is the report for the expenses."); // Add message body

                // Open the SMS app chooser
                Intent chooserIntent = Intent.createChooser(smsIntent, "Send SMS");
                chooserIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(chooserIntent);
                return true;

            case R.id.sendEmail:
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"soleilmaldonado15@gmail.com"});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Expense List");
                emailIntent.putExtra(Intent.EXTRA_TEXT, readListFromFile());
                if (emailIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(Intent.createChooser(emailIntent, "Send email..."));
                } else {
                    Toast.makeText(this, "No email app found!", Toast.LENGTH_SHORT).show();
                }
                return true;

            case R.id.exit:
                saveList();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveList() {
        try {
            File file = new File(getFilesDir(), "list.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);

            for (Expense expense : expensesList) {
                osw.write(expense + "\n");
            }
            osw.close();
            fos.close();

            speaker.speak("List saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
            Toast.makeText(this, "List saved successfully!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: List saved unsuccessfully.", Toast.LENGTH_LONG).show();
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }

    private String readListFromFile() {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            FileInputStream fileInputStream = openFileInput("list.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line).append("\n");
            }
            bufferedReader.close();
            inputStreamReader.close();
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }


}
