package com.example.cs480_project;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ViewExpenses extends AppCompatActivity implements TextToSpeech.OnInitListener{
    private ListView expensesListView;
    private List<Expense> expensesList;
    ExpenseTrackerDatabaseHelper dbHelper = new ExpenseTrackerDatabaseHelper(this);
    int expensePosition = -1;
    private TextToSpeech speaker;
    String tag = "Widgets";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_expenses);

        expensesListView = findViewById(R.id.expensesListView);
        expensesList = new ArrayList<>();

        // initialize text to speech engine
        speaker = new TextToSpeech(this, this);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        expensesList = dbHelper.selectExpenses();

        ArrayAdapter<Expense> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expensesList);
        expensesListView.setAdapter(adapter);

        expensesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                expensePosition = position;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.viewmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                Intent intent = new Intent(ViewExpenses.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.add:
                intent = new Intent(ViewExpenses.this, AddingExpenses.class);
                startActivity(intent);
                return true;
            case R.id.delete:
                Expense selectedExpense = expensesList.get(expensePosition);
                dbHelper.deleteExpense(selectedExpense.getId());
                expensesList.remove(selectedExpense);

                ArrayAdapter<Expense> adapter = (ArrayAdapter<Expense>) expensesListView.getAdapter();
                adapter.notifyDataSetChanged();

                speaker.speak("Expense deleted successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
                Toast.makeText(this, "Expense Deleted Successfully!", Toast.LENGTH_LONG).show();
                return true;
            case R.id.edit:
                selectedExpense = expensesList.get(expensePosition);
                intent = new Intent(ViewExpenses.this, AddingExpenses.class);
                intent.putExtra("id", selectedExpense.getId());
                intent.putExtra("amount", selectedExpense.getAmount());
                intent.putExtra("category", selectedExpense.getCategory());
                intent.putExtra("date", selectedExpense.getDate());
                intent.putExtra("description", selectedExpense.getDescription());
                intent.putExtra("receiptImage", selectedExpense.getReceiptImage());
                intent.putExtra("budgetId", selectedExpense.getBudgetId());

                startActivity(intent);
                return true;
            case R.id.save:
                saveList();
                return true;
            case R.id.exit:
                saveList();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveList() {
        try {
            File file = new File(getFilesDir(), "list.txt");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);

            for (Expense expense : expensesList) {
                osw.write(expense + "\n");
            }
            osw.close();
            fos.close();

            speaker.speak("List saved successfully!", TextToSpeech.QUEUE_FLUSH, null, "tts");
            Toast.makeText(this, "List saved successfully!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: List saved unsuccessfully.", Toast.LENGTH_LONG).show();
        }
    }

    //speak methods will send text to be spoken
    public void speak(String output){
        speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
    }

    // implements text to speech OnInitListener
    @Override
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            int result = speaker.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Language data is missing or the language is not supported.
                Log.e(tag, "Language is not available.");
            } else {
                // The TTS engine has been successfully initialized
                Log.i(tag, "TTS Initialization successful.");
            }
        } else {
            // Initialization failed.
            Log.e(tag, "Could not initialize TextToSpeech.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
    }
}
